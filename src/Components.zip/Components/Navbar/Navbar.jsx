import React from "react";
import Icon8 from "../Icons/Icon8";
import pic from "../../Asset/pic.svg";
import Icon9 from "../Icons/Icon9";

const Navbar = () => {
  return (
    <nav
      className="bg-[#ffffff1a] shadow-lg fixed top-0 z-10 mt-[2%]"
      style={{ width: "calc(100% - 310px)" }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 w-[100%]">
          <div className="flex-shrink-0 flex items-center">
            <a href="#" className="text-white font-bold text-lg">
              Your Logo
            </a>
          </div>
          <div className="flex items-center">
            <div className="w-[420px] h-[70px] bg-[white] flex items-center justify-evenly rounded-[40px]">
              <input
                type="text"
                placeholder="Search"
                className="px-4 py-[3.5%]  rounded-[40px] focus:outline-none focus:border-blue-500 w-[275px] bg-[#f4f7fe]"
              />
              <div className="flex  justify-between w-[15%]">
                <Icon8 />
                <Icon8 />
                <Icon9 />
              </div>
              <div className="w-12 h-12 bg-[white] rounded-full flex items-center justify-center">
                {" "}
                <img src={pic} alt="" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
